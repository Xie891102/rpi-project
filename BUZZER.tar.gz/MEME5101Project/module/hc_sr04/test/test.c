#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <string.h> 
#include "../hc_sr_ioctl.h" 

// 修改：將測量值寫入 distances 陣列
void sonic_measure(int distances[4]);

int main() {
    int distances[4];
    while(1){
        sonic_measure(distances);
        for(int i=0; i<4; i++) {
            printf("Distance%d: %d mm\n", i, distances[i]);
            if(distances[i]<30){
                printf("sonic%d error\n", i);
            }

        }
        sleep(1);
    }
    return 0;
}

void sonic_measure(int distances[4]){
    int trig_pin[4]={0,8,10,12};
    int echo_pin[4]={1,9,11,13};
    const char* devs[4]= {
        "/dev/ultrasonic0",
        "/dev/ultrasonic1",
        "/dev/ultrasonic2",
        "/dev/ultrasonic3"
    };

    int fds[4];
    for(int i=0;i<4;i++){
        fds[i]=open(devs[i], O_RDWR);
        if(fds[i] < 0) {
            perror("open");
            distances[i] = -1; // 如果開啟失敗，距離設為-1
        }
    }

    char buf[32];

    for(int i=0;i<4;i++){
        distances[i] = -1; // 預設為-1
        if(fds[i] < 0) continue;
        memset(buf, 0, sizeof(buf));
        ioctl(fds[i], HC_SR04_SET_TRIGGER, trig_pin[i]);
        ioctl(fds[i], HC_SR04_SET_ECHO, echo_pin[i]);
        int n = read(fds[i], buf, sizeof(buf));
        if(n > 0) {
            distances[i] = atoi(buf);  // 把回傳字串轉int
        }
        usleep(60000);
    }

    for(int i=0;i<4;i++){
        if(fds[i] >= 0)
            close(fds[i]);
    }
}
